#!/bin/bash

BASE_DIR="/hive/miners/custom/xntprover"
MINER="xntprover"
MINER_BIN="$BASE_DIR/$MINER"
VERSION_FILE="$BASE_DIR/version.txt"
PIDFILE="/var/run/xntprover-auto.pid"
TMP_DIR="/tmp/xntprover-update"

INTERVAL=300
MAX_IDLE=500

cd / || exit 1
mkdir -p "$TMP_DIR"

last_seen=$(date +%s)

while true; do
    now=$(date +%s)

    if pgrep -x "$MINER" >/dev/null 2>&1; then
        last_seen=$now
    else
        if [ $((now - last_seen)) -ge "$MAX_IDLE" ]; then
            echo "Miner not running for too long. Exiting auto-updater."
            rm -f "$PIDFILE"
            exit 0
        fi
    fi

    PAGE=$(curl -fs https://raw.githubusercontent.com/0xdrpool/xnt_gpu_guesser/main/download.md) || {
        sleep "$INTERVAL"
        continue
    }

    latest=$(echo "$PAGE" | grep -oE '^## V[0-9]+\.[0-9]+\.[0-9]+' | head -1 | sed 's/## V//')
    url=$(echo "$PAGE" | grep -oE 'https://[^ ]+xntprover-[0-9]+\.[0-9]+\.[0-9]+\.tar\.gz' | head -1)

    if [ -z "$latest" ] || [ -z "$url" ]; then
        sleep "$INTERVAL"
        continue
    fi

    if [ -x "$MINER_BIN" ]; then
        current=$("$MINER_BIN" --version | awk '{print $NF}')
    else
        current="none"
    fi

if [ "$latest" != "$current" ]; then
    echo "New version $latest detected (current $current)"
    miner stop && sleep 15

    rm -rf "$TMP_DIR"/*
    curl -fL "$url" -o "$TMP_DIR/xntprover.tar.gz" || {
        echo "Download failed"
        continue
    }

    tar -xzf "$TMP_DIR/xntprover.tar.gz" -C "$TMP_DIR" || {
        echo "Extraction failed"
        continue
    }

    BIN=$(find "$TMP_DIR" -type f -name "$MINER" -perm -u+x | head -1)
    if [ -z "$BIN" ]; then
        echo "Executable binary not found"
        continue
    fi

    mv -f "$BIN" "$MINER_BIN"
    chmod +x "$MINER_BIN"
    echo "$latest" > "$VERSION_FILE"
fi

    miner start
    sleep "$INTERVAL"
done
