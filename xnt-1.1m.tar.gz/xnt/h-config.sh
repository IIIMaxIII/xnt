#!/usr/bin/env bash

ADDRESS=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '(?<=--neptunewallet\s)\S+')
GPU=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '(?<=--gpu\s)\S+')

if [ -z "$GPU" ]; then
    cat > "$CUSTOM_CONFIG_FILENAME" << EOF
{
"selected": [
    "neptune-gpu"
  ],
  "algo_list": [
    {
      "id": "neptune-gpu",
      "algo": "xnt",
      "pool": "$CUSTOM_URL",
      "worker_name": "$HOSTNAME",
      "address": "$ADDRESS",
      "password": "$CUSTOM_PASS",
      "config": { "type": "gpu", "option": "all" },
      "idle_algos": ["gpu-xnt"]
    }
  ]
}
EOF
else
    IFS=',' read -ra GPU_ARRAY <<< "$GPU"

    SELECT_ARRAY=""
    for i in "${GPU_ARRAY[@]}"; do
        SELECT_ARRAY="${SELECT_ARRAY}${i},"
    done
    SELECT_ARRAY="${SELECT_ARRAY%,}"
    
    cat > "$CUSTOM_CONFIG_FILENAME" << EOF
{
  "selected": [
    "neptune-gpu"
  ],
  "algo_list": [
    {
      "id": "neptune-gpu",
      "algo": "xnt",
      "pool": "$CUSTOM_URL",
      "worker_name": "$HOSTNAME",
      "address": "$ADDRESS",
      "password": "$CUSTOM_PASS",
      "config": { "type": "gpu", "select": [${SELECT_ARRAY}] },
      "idle_algos": ["gpu-xnt"]
    }
  ]
}
EOF
fi

if [[ "$CUSTOM_USER_CONFIG" != *"--gpu"* ]]; then
	GPU=ALL
	conf_gpu="--gpu $GPU"
else
	GPU=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '(?<=--gpu[= ])[0-9,]+')
	conf_gpu="--gpu $GPU"
fi

# Create GPU.conf
echo "$conf_gpu" > $GPU_CONFIG_FILENAME
