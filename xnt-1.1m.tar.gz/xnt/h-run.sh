#!/usr/bin/env bash

echo -e "\e[32m***** OXZD v0.7.5 ***** \e[0m"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${BLUE}[$(date '+%Y/%m/%d %H:%M:%S')] INFO: $1${NC}"
}

log_success() {
    echo -e "${GREEN}[$(date '+%Y/%m/%d %H:%M:%S')] SUCCESS: $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}[$(date '+%Y/%m/%d %H:%M:%S')] WARNING: $1${NC}"
}

log_error() {
    echo -e "${RED}[$(date '+%Y/%m/%d %H:%M:%S')] ERROR: $1${NC}"
}

log_debug() {
    echo -e "${PURPLE}[$(date '+%Y/%m/%d %H:%M:%S')] DEBUG: $1${NC}"
}

log_monitor() {
    echo -e "${CYAN}[$(date '+%Y/%m/%d %H:%M:%S')] MONITOR: $1${NC}"
}

. h-manifest.conf

> "$CUSTOM_LOG_BASENAME"

RESTART_CHECK_INTERVAL=60
MAX_NO_CHANGE_TIME=300
MINER_PROCESS="xnt"

check_log_activity() {
    local current_time=$(date +%s)
    local last_modified=$(stat -c %Y "$CUSTOM_LOG_BASENAME" 2>/dev/null || echo 0)
    local time_diff=$((current_time - last_modified))

    if [[ $time_diff -ge $MAX_NO_CHANGE_TIME ]]; then
        log_warning "Log file has not changed for ${time_diff} seconds!"
        return 1
    else
        log_success "Log activity normal - last change ${time_diff} seconds ago"
        return 0
    fi
}

check_miner_health() {
    if ! pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_error "Miner process is not running!"
        return 1
    fi

    local recent_activity=$(tail -n 50 "$CUSTOM_LOG_BASENAME" | grep -Ei "accepted|share|hash|running")

    if [[ -z "$recent_activity" ]]; then
        local current_time=$(date +%s)
        local last_modified=$(stat -c %Y "$CUSTOM_LOG_BASENAME" 2>/dev/null || echo 0)
        local time_diff=$((current_time - last_modified))

        if [[ $time_diff -gt 120 ]]; then
            log_warning "No recent mining activity for ${time_diff} seconds!"
            return 1
        fi
    fi

    log_debug "Miner process is running and appears healthy"
    return 0
}

check_miner_process() {
    if ! pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_error "Miner process is not running!"
        return 1
    fi
    log_debug "Miner process is running normally"
    return 0
}

stop_miner() {
    log_warning "Stopping miner process..."
    pkill -f "$MINER_PROCESS"
    sleep 5

    if pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_warning "Forcing miner process termination..."
        pkill -9 -f "$MINER_PROCESS"
        sleep 2
    fi

    if ! pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_success "Miner process stopped successfully"
    else
        log_error "Failed to stop miner process!"
        return 1
    fi
    return 0
}

start_miner() {
    log_info "Starting miner..."

    if [[ ! -f "$CUSTOM_CONFIG_FILENAME" ]]; then
        log_error "Configuration file $CUSTOM_CONFIG_FILENAME not found!"
        return 1
    fi

    log_debug "Executing XNT Neptune Privacy Miner..."
    ./xnt run --config "$CUSTOM_CONFIG_FILENAME" 2>&1 | tee -a "$CUSTOM_LOG_BASENAME" &
    sleep 10

    if check_miner_process; then
        log_success "Miner started successfully"
        touch "$CUSTOM_LOG_BASENAME"
        return 0
    else
        log_error "Failed to start miner!"
        return 1
    fi
}

monitor_loop() {
    local consecutive_errors=0
    local max_consecutive_errors=3

    log_monitor "Miner monitoring started"
    log_info "Check interval: ${RESTART_CHECK_INTERVAL} seconds"
    log_info "Maximum inactivity: ${MAX_NO_CHANGE_TIME} seconds"

    while true; do
        log_debug "--- Monitoring cycle started ---"

        if [[ ! -f "$CUSTOM_LOG_BASENAME" ]]; then
            log_warning "Log file not created, checking miner status..."
            if ! check_miner_process; then
                log_warning "Miner not running, attempting to start..."
                start_miner
            fi
            sleep $RESTART_CHECK_INTERVAL
            continue
        fi

        if ! check_miner_process; then
            log_error "Miner process not found! Restarting..."
            if start_miner; then
                consecutive_errors=0
                log_success "Miner restarted after process loss"
            else
                consecutive_errors=$((consecutive_errors + 1))
                log_error "Failed to restart miner ($consecutive_errors)"
            fi
            sleep $RESTART_CHECK_INTERVAL
            continue
        fi

        if ! check_miner_health; then
            consecutive_errors=$((consecutive_errors + 1))
            log_warning "Miner health check failed ($consecutive_errors)"

            if [[ $consecutive_errors -ge $max_consecutive_errors ]]; then
                log_error "Health failure threshold! Restarting miner..."
                if stop_miner && start_miner; then
                    log_success "Miner restarted after health failure"
                    consecutive_errors=0
                else
                    log_error "Restart procedure failed!"
                fi
            fi
        else
            consecutive_errors=0
        fi

        if ! check_log_activity; then
            consecutive_errors=$((consecutive_errors + 1))
            log_warning "Log inactivity detected ($consecutive_errors)"

            if [[ $consecutive_errors -ge $max_consecutive_errors ]]; then
                log_error "Log inactivity threshold! Restarting miner..."
                if stop_miner && start_miner; then
                    log_success "Miner restarted after inactivity"
                    consecutive_errors=0
                else
                    log_error "Restart procedure failed!"
                fi
            fi
        else
            consecutive_errors=0
        fi

        log_debug "--- Monitoring cycle completed ---"
        sleep $RESTART_CHECK_INTERVAL
    done
}

initialize_miner() {
    log_monitor "Initializing miner..."

    if [[ ! -f "$CUSTOM_CONFIG_FILENAME" ]]; then
        log_error "Configuration file $CUSTOM_CONFIG_FILENAME not found!"
        exit 1
    fi

    log_info "Clearing log file: $CUSTOM_LOG_BASENAME"
    > "$CUSTOM_LOG_BASENAME"

    if start_miner; then
        log_success "Miner initialized successfully"
    else
        log_error "Failed to initialize miner!"
        exit 1
    fi
}

main() {
    log_monitor "=== Miner Auto-Restart System Started ==="
    log_info "Process: $MINER_PROCESS"
    log_info "Config: $CUSTOM_CONFIG_FILENAME"
    log_info "Logfile: $CUSTOM_LOG_BASENAME"

    initialize_miner
    monitor_loop
}

 trap 'log_monitor "Shutdown signal received, stopping monitor..."; exit 0' SIGINT SIGTERM

main
