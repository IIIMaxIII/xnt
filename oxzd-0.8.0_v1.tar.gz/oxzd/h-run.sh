#!/usr/bin/env bash

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Logging functions with timestamps and color coding
log_info() {
    echo -e "${BLUE}[$(date '+%Y/%m/%d %H:%M:%S')] INFO: $1${NC}"
}

log_success() {
    echo -e "${GREEN}[$(date '+%Y/%m/%d %H:%M:%S')] SUCCESS: $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}[$(date '+%Y/%m/%d %H:%M:%S')] WARNING: $1${NC}"
}

log_error() {
    echo -e "${RED}[$(date '+%Y/%m/%d %H:%M:%S')] ERROR: $1${NC}"
}

log_debug() {
    echo -e "${PURPLE}[$(date '+%Y/%m/%d %H:%M:%S')] DEBUG: $1${NC}"
}

log_monitor() {
    echo -e "${CYAN}[$(date '+%Y/%m/%d %H:%M:%S')] MONITOR: $1${NC}"
}

# Load custom configuration
. h-manifest.conf

# Clear previous log
> "$CUSTOM_LOG_BASENAME"

# Configuration variables
RESTART_CHECK_INTERVAL=60      # Interval between monitoring cycles
MAX_NO_CHANGE_TIME=300         # Max allowed inactivity in log (seconds)
MINER_PROCESS="xnt"            # Miner process name (generic placeholder)

# Function to check if log file is updating
check_log_activity() {
    local current_time=$(date +%s)
    local last_modified=$(stat -c %Y "$CUSTOM_LOG_BASENAME" 2>/dev/null || echo)
    local time_diff=$((current_time - last_modified))

    if [[ $time_diff -ge $MAX_NO_CHANGE_TIME ]]; then
        log_warning "Log file has not changed for ${time_diff} seconds!"
        return 1
    else
        log_success "Log activity normal - last change ${time_diff} seconds ago"
        return 0
    fi
}

# Function to check miner health based on process and recent log activity
check_miner_health() {
    if ! pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_error "Miner process is not running!"
        return 1
    fi

    local recent_activity=$(tail -n 50 "$CUSTOM_LOG_BASENAME" | grep -Ei "accept")

    if [[ -z "$recent_activity" ]]; then
        local current_time=$(date +%s)
        local last_modified=$(stat -c %Y "$CUSTOM_LOG_BASENAME" 2>/dev/null || echo)
        local time_diff=$((current_time - last_modified))

        if [[ $time_diff -gt 120 ]]; then
            log_warning "No recent mining activity for ${time_diff} seconds!"
            return 1
        fi
    fi

    log_debug "Miner process is running and appears healthy"
    return 0
}

# Check if miner process is running
check_miner_process() {
    if ! pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_error "Miner process is not running!"
        return 1
    fi
    log_debug "Miner process is running normally"
    return 0
}

# Stop miner safely
stop_miner() {
    log_warning "Stopping miner process..."
    pkill -f "$MINER_PROCESS"
    sleep 5

    # Force kill if still running
    if pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_warning "Forcing miner process termination..."
        pkill -9 -f "$MINER_PROCESS"
        sleep 2
    fi

    if ! pgrep -f "$MINER_PROCESS" > /dev/null; then
        log_success "Miner process stopped successfully"
    else
        log_error "Failed to stop miner process!"
        return 1
    fi
    return 0
}

# Start miner with configuration and auto-select binary based on CPU architecture
start_miner() {
    log_info "Starting miner..."

    if [[ ! -f "$CUSTOM_CONFIG_FILENAME" ]]; then
        log_error "Configuration file $CUSTOM_CONFIG_FILENAME not found!"
        return 1
    fi

# Detect CPU architecture more reliably
cpu_model=$(grep "model name" /proc/cpuinfo | head -n1)
cpu_flags=$(grep "flags" /proc/cpuinfo | head -n1)

binary="./oxzd-x86-64"  # default binary

if echo "$cpu_model" | grep -qi "Ryzen.*3[7-9]00X"; then
    binary="./oxzd-znver2"
    log_info "Detected CPU: Ryzen Zen 2 (znver2). Using $binary"
elif echo "$cpu_flags" | grep -qi "znver4"; then
    binary="./oxzd-znver4"
    log_info "Detected CPU: Zen 4 (znver4). Using $binary"
else
    log_info "Detected CPU: Generic x86-64. Using $binary"
fi

    # Check if binary exists
    if [[ ! -f "$binary" ]]; then
        log_error "Miner binary $binary not found!"
        return 1
    fi

    log_debug "Executing miner binary $binary with config $CUSTOM_CONFIG_FILENAME..."
    "$binary" run --config "$CUSTOM_CONFIG_FILENAME" 2>&1 | tee -a "$CUSTOM_LOG_BASENAME"
    sleep 10

    # Update MINER_PROCESS to the selected binary name for monitoring
    MINER_PROCESS=$(basename "$binary")

    if check_miner_process; then
        log_success "Miner started successfully"
        touch "$CUSTOM_LOG_BASENAME"
        return 0
    else
        log_error "Failed to start miner!"
        return 1
    fi
}

# Main monitoring loop
monitor_loop() {
    local consecutive_errors=0
    local max_consecutive_errors=3

    log_monitor "Miner monitoring started"
    log_info "Check interval: ${RESTART_CHECK_INTERVAL} seconds"
    log_info "Maximum inactivity: ${MAX_NO_CHANGE_TIME} seconds"

    while true; do
        log_debug "--- Monitoring cycle started ---"

        # Ensure log file exists
        if [[ ! -f "$CUSTOM_LOG_BASENAME" ]]; then
            log_warning "Log file not created, checking miner status..."
            if ! check_miner_process; then
                log_warning "Miner not running, attempting to start..."
                start_miner
            fi
            sleep $RESTART_CHECK_INTERVAL
            continue
        fi

        # Restart miner if process not found
        if ! check_miner_process; then
            log_error "Miner process not found! Restarting..."
            if start_miner; then
                consecutive_errors=0
                log_success "Miner restarted after process loss"
            else
                consecutive_errors=$((consecutive_errors + 1))
                log_error "Failed to restart miner ($consecutive_errors)"
            fi
            sleep $RESTART_CHECK_INTERVAL
            continue
        fi

        # Check miner health
        if ! check_miner_health; then
            consecutive_errors=$((consecutive_errors + 1))
            log_warning "Miner health check failed ($consecutive_errors)"

            if [[ $consecutive_errors -ge $max_consecutive_errors ]]; then
                log_error "Health failure threshold! Restarting miner..."
                if stop_miner && start_miner; then
                    log_success "Miner restarted after health failure"
                    consecutive_errors=0
                else
                    log_error "Restart procedure failed!"
                fi
            fi
        else
            consecutive_errors=0
        fi

        # Check log activity
        if ! check_log_activity; then
            consecutive_errors=$((consecutive_errors + 1))
            log_warning "Log inactivity detected ($consecutive_errors)"

            if [[ $consecutive_errors -ge $max_consecutive_errors ]]; then
                log_error "Log inactivity threshold! Restarting miner..."
                if stop_miner && start_miner; then
                    log_success "Miner restarted after inactivity"
                    consecutive_errors=0
                else
                    log_error "Restart procedure failed!"
                fi
            fi
        else
            consecutive_errors=0
        fi

        log_debug "--- Monitoring cycle completed ---"
        sleep $RESTART_CHECK_INTERVAL
    done
}

# Initialize miner before monitoring
initialize_miner() {
    log_monitor "Initializing miner..."

    if [[ ! -f "$CUSTOM_CONFIG_FILENAME" ]]; then
        log_error "Configuration file $CUSTOM_CONFIG_FILENAME not found!"
        exit 1
    fi

    log_info "Clearing log file: $CUSTOM_LOG_BASENAME"
    > "$CUSTOM_LOG_BASENAME"

    if start_miner; then
        log_success "Miner initialized successfully"
    else
        log_error "Failed to initialize miner!"
        exit 1
    fi
}

# Main entry point
main() {
    log_monitor "=== Miner Auto-Restart System Started ==="
    log_info "Process: $MINER_PROCESS"
    log_info "Config: $CUSTOM_CONFIG_FILENAME"
    log_info "Logfile: $CUSTOM_LOG_BASENAME"

    initialize_miner
    monitor_loop
}

# Trap shutdown signal
trap 'log_monitor "Shutdown signal received, stopping monitor..."; exit 0' SIGINT SIGTERM

main
