#!/usr/bin/env bash
. /hive/miners/custom/xntprover/h-manifest.conf

# 1) Если -g задан пользователем — пишем как есть
if echo " ${CUSTOM_USER_CONFIG} " | grep -Eq '(^|[[:space:]])-g([[:space:]]|=)'; then
  echo --pool "${CUSTOM_URL}" --worker "${CUSTOM_TEMPLATE}" ${CUSTOM_USER_CONFIG} > "${CUSTOM_CONFIG_FILENAME}"

# 2) Иначе формируем -g 0,1,2,... по количеству NVIDIA
else
  n="$(nvidia-smi -L 2>/dev/null | wc -l | awk '{print $1}')"
  glist="$(seq 0 $((n-1)) | paste -sd, -)"
  echo --pool "${CUSTOM_URL}" --worker "${CUSTOM_TEMPLATE}" -g "${glist}" ${CUSTOM_USER_CONFIG} > "${CUSTOM_CONFIG_FILENAME}"
fi
