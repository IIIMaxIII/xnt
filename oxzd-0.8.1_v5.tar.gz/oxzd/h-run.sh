#!/usr/bin/env bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR" || { echo "ERROR: Cannot cd to $SCRIPT_DIR"; exit 1; }

. h-manifest.conf

CYAN="\e[36m"
NOCOLOR="\e[0m"

ARG=$(< "$CUSTOM_CONFIG_FILENAME")

if [[ $ARG == *"--version=ver4"* ]]; then
    MINERBIN="oxzd-znver4"
    echo -e "${CYAN}Using Ver4 binary${NOCOLOR}"
elif [[ $ARG == *"--version=ver2"* ]]; then
    MINERBIN="oxzd-znver2"
    echo -e "${CYAN}Using Ver2 binary${NOCOLOR}"
else
    MINERBIN="oxzd-x86-64"
    echo -e "${CYAN}Using default binary${NOCOLOR}"
fi

ARG=$(echo "$ARG" | sed -E 's/--version=[^ ]+//g')

eval "./$MINERBIN run-gpu --algo xnt ${ARG}" 2>&1 | tee "${CUSTOM_LOG_BASENAME}"
