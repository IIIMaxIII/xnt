#!/usr/bin/env bash

. /hive/miners/custom/oxzd/h-manifest.conf

if [[ -f "$GPU_CONFIG_FILENAME" ]]; then
    GPU_LINE=$(grep -Eo -- '--gpu[= ][0-9,]+' "$GPU_CONFIG_FILENAME" | head -n 1)
    if [[ -n "$GPU_LINE" ]]; then
        GPU_NUMBERS=$(echo "$GPU_LINE" | grep -oE '[0-9,]+')
        IFS=',' read -r -a active_gpus <<< "$GPU_NUMBERS"
        echo "[>] GPU.conf -> ACTIVE GPUs: ${active_gpus[*]}"
    else
        echo "[!] '--gpu' not found in GPU.conf"
	echo "[!] All GPUs are active: (${active_gpus[*]})"
        active_gpus=()
    fi
else
    echo "[!] GPU.conf not found!"
    echo "[!] All GPUs are active!"
    active_gpus=()
fi

if [[ ${#active_gpus[@]} -eq 0 ]]; then
    gpu_count=$(nvidia-smi -L | wc -l)
    active_gpus=($(seq 0 $((gpu_count - 1))))
    echo "[>] GPU.conf is empty!"
    echo "[>] All GPUs are active: (${active_gpus[*]})"
fi

if [[ ! -f "$CUSTOM_LOG_BASENAME" ]]; then
    echo "[!] Log file not found !"
    exit 1
fi

current_time=$(date +%s)
last_modified=$(stat -c %Y "$CUSTOM_LOG_BASENAME" 2>/dev/null || echo 0)
time_diff=$((current_time - last_modified))
MAX_INACTIVITY=300  # 5 dakika = 300 saniye

if [[ $time_diff -ge $MAX_INACTIVITY ]]; then
    recent_gpu_hashrate=$(tail -n 200 "$CUSTOM_LOG_BASENAME" | grep -E "GPU[0-9]+.*MH/s" | tail -n 1)
    
    if [[ -z "$recent_gpu_hashrate" ]]; then
        exit 0
    fi
    
    if [[ "$recent_gpu_hashrate" =~ [0-9]{4}-[0-9]{2}-[0-9]{2}[[:space:]]+[0-9]{2}:[0-9]{2}:[0-9]{2} ]]; then
        log_timestamp=$(echo "$recent_gpu_hashrate" | grep -oE '[0-9]{4}-[0-9]{2}-[0-9]{2}[[:space:]]+[0-9]{2}:[0-9]{2}:[0-9]{2}')
        log_time=$(date -d "$log_timestamp" +%s 2>/dev/null || echo 0)
        if [[ $log_time -gt 0 ]]; then
            log_time_diff=$((current_time - log_time))
            if [[ $log_time_diff -ge $MAX_INACTIVITY ]]; then
                exit 0
            fi
        fi
    fi
fi

accepted_shares=$(grep -c "Solution was accepted" "$CUSTOM_LOG_BASENAME")
rejected_shares=0

for ((miner_index=0; miner_index<${#active_gpus[@]}; miner_index++)); do			# Log format: "GPU0 [NVIDIA RTX A5000] | tip5  | 6.31 MH/s | 100%  | 220 W | 70 °C"
    gpu_raw=$(grep "GPU$miner_index" "$CUSTOM_LOG_BASENAME" | grep "MH/s" | tail -n 1)
    if [[ -n "$gpu_raw" ]]; then
        hashrate_str=$(echo "$gpu_raw" | grep -o '[0-9.]* MH/s' | cut -d' ' -f1)		# get value MH/s
        hashrate=$(echo "$hashrate_str * 1000000" | bc | cut -d'.' -f1)				# Convert MH/s to H/s (1 MH/s = 1,000,000 H/s)
    else
        hashrate=0
        hashrate_str="0"
    fi
    miner_hashrates[$miner_index]=$hashrate
    physical_gpu=${active_gpus[$miner_index]}
    echo "Miner GPU$miner_index  →  Physical GPU $physical_gpu  | Hashrate: ${miner_hashrates[$miner_index]} H/s (${hashrate_str} MH/s)"
    total_hashrate_sum=$((total_hashrate_sum + hashrate))
done

echo "---------------------------------------"
echo "[>] Total Hashrate: $total_hashrate_sum H/s"
echo "---------------------------------------"

if [[ -f "$GPU_STATS_JSON" ]]; then
    readarray -t gpu_stats < <(jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' "$GPU_STATS_JSON" 2>/dev/null)
    busids=(${gpu_stats[0]})
    brands=(${gpu_stats[1]})
    temps=(${gpu_stats[2]})
    fans=(${gpu_stats[3]})
    gpu_count=${#busids[@]}
else
    echo "[!] GPU_STATS_JSON file not found!"
    exit 1
fi

hash_arr=()
busid_arr=()
temp_arr=()
fan_arr=()

echo "[DEBUG] Total GPU count: $gpu_count"
echo "[DEBUG] Brands: ${brands[*]}"

# ONLY NVIDIA GPU
nvidia_gpu_count=0
nvidia_gpu_indices=()

for ((i=0; i<gpu_count; i++)); do
    if [[ "${brands[i]}" == "nvidia" ]]; then
        nvidia_gpu_indices+=($i)
        ((nvidia_gpu_count++))
        echo "[DEBUG] NVIDIA GPU found: Index $i, Bus ID: ${busids[i]}"
    else
        echo "[DEBUG] Skipping: Index $i, Brand: ${brands[i]}"
    fi
done

echo "[DEBUG] Total NVIDIA GPU count: $nvidia_gpu_count"

# NVIDIA GPU cycle
for nvidia_index in "${!nvidia_gpu_indices[@]}"; do
    physical_index=${nvidia_gpu_indices[$nvidia_index]}
    
    [[ "${busids[physical_index]}" =~ ^([A-Fa-f0-9]+): ]]
    busid_arr+=($((16#${BASH_REMATCH[1]})))
    temp_arr+=(${temps[physical_index]})
    fan_arr+=(${fans[physical_index]})
    
    # is this NVIDIA GPU active?
    if [[ " ${active_gpus[@]} " =~ " $nvidia_index " ]]; then
        found_index=-1
        for idx in "${!active_gpus[@]}"; do
            if [[ "${active_gpus[$idx]}" == "$nvidia_index" ]]; then
                found_index=$idx
                break
            fi
        done
        if [[ $found_index -ge 0 ]]; then
            gpu_hashrate=${miner_hashrates[$found_index]}
            echo "✓ NVIDIA GPU $nvidia_index (Physical $physical_index) -> Miner GPU$found_index ACTIVE | Hashrate: $gpu_hashrate H/s"
            hash_arr+=($gpu_hashrate)
        else
            echo "✗ NVIDIA GPU $nvidia_index (Physical $physical_index) ACTIVE but no miner data"
            hash_arr+=(0)
        fi
    else
        echo "✗ NVIDIA GPU $nvidia_index (Physical $physical_index) - INACTIVE (not in GPU.conf)"
        hash_arr+=(0)
    fi
done

if [[ ${#hash_arr[@]} -eq 0 ]] && [[ $nvidia_gpu_count -gt 0 ]]; then
    echo "[WARNING] hash_arr boş, NVIDIA GPU'lar için 0 ekleniyor"
    for ((i=0; i<nvidia_gpu_count; i++)); do
        hash_arr+=(0)
    done
fi

hash_json=$(printf '%s\n' "${hash_arr[@]}" | jq -cs '.')
bus_json=$(printf '%s\n' "${busid_arr[@]}" | jq -cs '.')
temp_json=$(printf '%s\n' "${temp_arr[@]}" | jq -cs '.')
fan_json=$(printf '%s\n' "${fan_arr[@]}" | jq -cs '.')

uptime=$(( $(date +%s) - $(stat -c %Y "$CUSTOM_CONFIG_FILENAME") ))

stats=$(jq -nc \
    --argjson hs "$hash_json" \
    --arg ver "$CUSTOM_VERSION" \
    --argjson bus "$bus_json" \
    --argjson temp "$temp_json" \
    --argjson fan "$fan_json" \
    --arg uptime "$uptime" \
    --argjson accepted "$accepted_shares" \
    --argjson rejected "$rejected_shares" \
    '{hs:$hs, hs_units:"hs", algo:"XNT", ver:$ver, uptime:$uptime, ar:[$accepted,$rejected], bus_numbers:$bus, temp:$temp, fan:$fan}')

khs=$(echo "scale=2; $total_hashrate_sum/1000" | bc)

echo ""
echo "==================== DEBUG ===================="
echo "Toplam Hashrate : $khs kH/s"
echo "Accepted Shares : $accepted_shares"
echo "Rejected Shares : $rejected_shares"
echo "Hash Array      : ${hash_arr[*]}"
echo "Output JSON     : $stats"
echo "================================================"