#!/bin/bash

BASE_DIR="/hive/miners/custom/xntprover"
MINER="xntprover"
MINER_BIN="$BASE_DIR/$MINER"
VERSION_FILE="$BASE_DIR/version.txt"
PIDFILE="/var/run/xntprover-auto.pid"

INTERVAL=300
MAX_IDLE=500

cd / || exit 1

last_seen=$(date +%s)

while true; do
    now=$(date +%s)

    if pgrep -x "$MINER" >/dev/null 2>&1; then
        last_seen=$now
    else
        if [ $((now - last_seen)) -ge "$MAX_IDLE" ]; then
            echo "Miner not running for too long. Exiting auto-updater."
            rm -f "$PIDFILE"
            exit 0
        fi
    fi

    latest=$(curl -fs \
        https://raw.githubusercontent.com/0xdrpool/xnt_gpu_guesser/main/download.md |
        grep -o "xntprover-[0-9]\+\.[0-9]\+\.[0-9]\+" |
        head -1 |
        sed 's/xntprover-//'
    )

    if [ -n "$latest" ] && [ -x "$MINER_BIN" ]; then
        current=$("$MINER_BIN" --version | awk '{print $NF}')

        if [ "$latest" != "$current" ]; then
            echo "New version $latest detected (current $current)"
            echo "Stopping miner for update"
            miner stop
        fi
    fi

    sleep "$INTERVAL"
done
