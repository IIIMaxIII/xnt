#!/usr/bin/env bash
# HiveOS agent SOURCES this file. Must set variables: khs and stats.

. /hive/miners/custom/xntprover/h-manifest.conf

LOG_FILE="${CUSTOM_LOG_BASENAME}.log"
CONF_FILE="${CUSTOM_CONFIG_FILENAME}"
ver="${CUSTOM_VERSION} v5"

# --- defaults ---
khs=0
stats="$(jq -nc --arg ver "$ver" '{hs:[0], hs_units:"mhs", temp:[], fan:[], uptime:0, ar:[0,0], ver:$ver, algo:"xnt"}')"

# --- gpu_count (Hive indices 0..N-1) ---
gpu_count="$(nvidia-smi -L 2>/dev/null | wc -l | awk '{print $1}')"
[[ -z "$gpu_count" || "$gpu_count" -le 0 ]] && gpu_count=1

# --- uptime ONLY from conf mtime ---
uptime=0
start="$(stat -c %Y "$CONF_FILE" 2>/dev/null || echo 0)"
now="$(date +%s)"
if [[ "$start" -gt 0 && "$now" -ge "$start" ]]; then
  uptime=$((now - start))
fi

# --- temps/fans (aligned by index) ---
temp_json="$(
  nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null \
  | jq -cs 'map(tonumber)'
)"
fan_json="$(
  nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null \
  | jq -cs 'map(tonumber)'
)"

# --- shares from log ("submit:") ---
acc=0
rej=0
[[ -f "$LOG_FILE" ]] && acc="$(grep -c "submit:" "$LOG_FILE" 2>/dev/null || true)"
acc="${acc:-0}"

# --- parse per-GPU speeds from log, aligned hs[] (M/s) ---
hs_json='[]'
if [[ -f "$LOG_FILE" ]]; then
  hs_csv="$(
    tail -n 800 "$LOG_FILE" 2>/dev/null | awk -v gc="$gpu_count" '
      /^\|GPU[0-9]+/{
        idx=$1
        sub(/^\|GPU/, "", idx)      # "|GPU0" -> "0"
        gsub(/[^0-9].*/, "", idx)  # safety
        last=""
        for (i=1;i<=NF;i++) if ($i ~ /^[0-9]+(\.[0-9]+)?$/) last=$i
        if (idx ~ /^[0-9]+$/ && last != "") rate[idx]=last
      }
      END{
        for (i=0;i<gc;i++){
          v = ((i in rate) ? rate[i] : 0)
          printf "%s%.3f", (i?",":""), v
        }
      }'
  )"
  hs_json="$(printf '%s' "$hs_csv" | jq -cRs 'split(",") | map(tonumber)')"
fi

# --- total khs for Hive (khs variable is required) ---
total_mhs="$(echo "$hs_json" | jq -r 'add // 0')"
khs="$(awk -v mhs="$total_mhs" 'BEGIN{printf "%.0f", (mhs*1000)}')"

# --- final stats JSON ---
stats="$(jq -nc \
  --arg ver "$ver" \
  --argjson hs "$hs_json" \
  --arg hs_units "mhs" \
  --argjson temp "$temp_json" \
  --argjson fan "$fan_json" \
  --argjson uptime "$uptime" \
  --argjson ar "[${acc},${rej}]" \
  '{hs:$hs, hs_units:$hs_units, temp:$temp, fan:$fan, uptime:$uptime, ar:$ar, ver:$ver, algo:"xnt"}'
)"
