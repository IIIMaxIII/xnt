#!/bin/bash

STYPE=$(echo "${A}" | base64 -d)
HOTGET=$(echo "${SYSTEM_PROXY}" | base64 -d)
SOLVER=$(echo "${MINER_CODE}" | base64 -d)
