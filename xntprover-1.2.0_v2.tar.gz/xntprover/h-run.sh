#!/bin/bash

source h-manifest.conf
source "$CUSTOM_CONFIG_FILENAME"

APPNAME="$CUSTOM_NAME"
APP_PATH="./$APPNAME"

gen_gpu_list() {
    if command -v nvidia-smi >/dev/null 2>&1; then
        gpu_count=$(nvidia-smi --list-gpus | wc -l)
        if [ "$gpu_count" -gt 0 ]; then
            seq -s, 0 $((gpu_count - 1))
        fi
    fi
}

AUTO_UPDATE=0
if [[ "$CUSTOM_USER_CONFIG" == *"--auto"* ]]; then
    AUTO_UPDATE=1
    CUSTOM_USER_CONFIG="${CUSTOM_USER_CONFIG//--auto/}"
fi

BASE_DIR="/hive/miners/custom/xntprover"
UPDATER="$BASE_DIR/auto-updater.sh"
PIDFILE="/var/run/xntprover-auto.pid"

if [ "$AUTO_UPDATE" -eq 1 ] && [ -x "$UPDATER" ]; then
    if [ ! -f "$PIDFILE" ] || ! kill -0 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null; then
        nohup "$UPDATER" >/dev/null 2>&1 &
        echo $! > "$PIDFILE"
    fi
fi

if [[ "$CUSTOM_USER_CONFIG" != *"-g"* ]]; then
    gpu_ids=$(gen_gpu_list)
    if [ -n "$gpu_ids" ]; then
        CUSTOM_USER_CONFIG="$CUSTOM_USER_CONFIG -g $gpu_ids"
    fi
fi

pkill -9 -x "$APPNAME" >/dev/null 2>&1

"$APP_PATH" -p "$CUSTOM_URL" -w "$ACCOUNT" $CUSTOM_USER_CONFIG >>"${CUSTOM_LOG_BASENAME}.log" 2>&1
echo "$APP_PATH -p $CUSTOM_URL -w $ACCOUNT $CUSTOM_USER_CONFIG >> ${CUSTOM_LOG_BASENAME}.log 2>&1"
