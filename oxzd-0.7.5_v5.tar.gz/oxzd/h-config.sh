#!/usr/bin/env bash
# Allowed variables: WORKER_NAME CUSTOM_TEMPLATE CUSTOM_URL CUSTOM_PASS CUSTOM_ALGO CUSTOM_USER_CONFIG CUSTOM_CONFIG_FILENAME

[[ -e /hive/miners/custom ]] && . /hive/miners/custom/oxzd/h-manifest.conf

[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

# Base configuration
CONFIG=""
CONFIG="--pool ${CUSTOM_URL} --worker ${WORKER_NAME} --address ${CUSTOM_TEMPLATE}"

[[ ! -z $CUSTOM_USER_CONFIG ]] && CONFIG+=" $CUSTOM_USER_CONFIG"

# Save final config
echo "$CONFIG" > "$CUSTOM_CONFIG_FILENAME"

# Debug output
# echo "[DEBUG] Config: $CONFIG" >&2
