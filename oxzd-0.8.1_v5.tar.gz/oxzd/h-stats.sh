#!/usr/bin/env bash

. /hive/miners/custom/oxzd/h-manifest.conf

LOG_FILE="${CUSTOM_LOG_BASENAME}"
CONF_FILE="/hive/miners/custom/oxzd/oxzd.conf"

algo="xnt"
version="${CUSTOM_VERSION} ${CUSTOM_BUILD}"

stats="null"

########################################
# Helpers
########################################

# Get number of NVIDIA GPUs
get_gpu_count() {
    local n
    n=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | wc -l)
    [[ -z "$n" || "$n" -le 0 ]] && echo 0 || echo "$n"
}

########################################
# Main
########################################

if [[ -f "$LOG_FILE" && -f "$CONF_FILE" ]]; then

    # Calculate uptime based on file modification times
    log_ts=$(stat -c %Y "$LOG_FILE" 2>/dev/null || echo 0)
    conf_ts=$(stat -c %Y "$CONF_FILE" 2>/dev/null || echo 0)
    uptime_sec=$((log_ts - conf_ts))
    (( uptime_sec < 0 )) && uptime_sec=0

    # Read the last 100 lines of the log
    log_tail=$(tail -n 100 "$LOG_FILE" 2>/dev/null)
    total_khs_from_log=""
    declare -a hs_arr_khs
    max_gpu_index=-1

    # ---------------------------------
    # Single pass through log: parse per-GPU and Total hash rate
    # ---------------------------------
    while IFS= read -r line; do
        [[ "$line" != *"INFO"* ]] || [[ "$line" != *"MH/s"* ]] || [[ "$line" != *"xnt"* ]] && continue

        # Parse individual GPU hashrates
        if [[ $line =~ GPU([0-9]+).*xnt[[:space:]]*\|[[:space:]]*([0-9.]+)[[:space:]]*MH/s ]]; then
            idx="${BASH_REMATCH[1]}"
            rate_mhs="${BASH_REMATCH[2]}"
            hs_arr_khs[idx]=$(awk -v r="$rate_mhs" 'BEGIN{printf "%.0f", r*1000}')
            (( idx > max_gpu_index )) && max_gpu_index=$idx
            continue
        fi

        # Parse total hashrate
        if [[ $line =~ Total[[:space:]]*\|[[:space:]]*xnt:[[:space:]]*([0-9.]+)[[:space:]]*MH/s ]]; then
            total_khs_from_log=$(awk -v r="${BASH_REMATCH[1]}" 'BEGIN{printf "%.0f", r*1000}')
        fi
    done <<< "$log_tail"

    # Get GPU count, fallback to max GPU index
    gpu_count=$(get_gpu_count)
    [[ "$gpu_count" -le 0 ]] && gpu_count=$((max_gpu_index + 1))
    [[ "$gpu_count" -le 0 ]] && gpu_count=1

    # Initialize arrays
    temp_arr=()
    fan_arr=()
    busid_arr=()
    out_hs=()
    for ((i=0;i<gpu_count;i++)); do
        temp_arr+=(0)
        fan_arr+=(0)
        busid_arr+=(0)
        out_hs+=( "${hs_arr_khs[i]:-0}" )
    done

    # Query hardware stats from nvidia-smi
    gpu_stats_raw=$(nvidia-smi --query-gpu=temperature.gpu,fan.speed,pci.bus_id --format=csv,noheader,nounits 2>/dev/null)
    i=0
    while IFS=',' read -r t f b; do
        (( i >= gpu_count )) && break
        [[ -z "$t" ]] && t=0
        [[ -z "$f" ]] && f=0
        bus_hex=$(echo "$b" | cut -d':' -f2 | cut -d'.' -f1 2>/dev/null || echo "00")
        [[ "$bus_hex" =~ ^[A-Fa-f0-9]+$ ]] || bus_hex="00"

        temp_arr[$i]=$t
        fan_arr[$i]=$f
        busid_arr[$i]=$((16#${bus_hex}))
        ((i++))
    done <<< "$gpu_stats_raw"

    # Use total from log if available, otherwise sum per-GPU
    if [[ -n "$total_khs_from_log" ]]; then
        total_khs="$total_khs_from_log"
    else
        total_khs=0
        for v in "${hs_arr_khs[@]}"; do
            total_khs=$((total_khs + v))
        done
    fi

    # Count accepted shares
    accepted_shares=$(awk '/\[xnt\][[:space:]]+Solution was accepted/ {c++} END {print c+0}' "$LOG_FILE" 2>/dev/null)
    rejected_shares=0

    # Build JSON for HiveOS
    stats=$(jq -nc \
        --argjson hs "$(printf '%s\n' "${out_hs[@]}" | jq -cs '.')" \
        --arg ver "$version" \
        --arg algo "$algo" \
        --arg uptime "$uptime_sec" \
        --argjson ac "$accepted_shares" \
        --argjson rj "$rejected_shares" \
        --argjson khs "$total_khs" \
        --argjson bus "$(printf '%s\n' "${busid_arr[@]}" | jq -cs '.')" \
        --argjson temp "$(printf '%s\n' "${temp_arr[@]}" | jq -cs '.')" \
        --argjson fan "$(printf '%s\n' "${fan_arr[@]}" | jq -cs '.')" \
        '{
            hs: $hs,
            hs_units: "khs",
            ver: $ver,
            algo: $algo,
            uptime: ($uptime|tonumber),
            ar: [$ac,$rj],
            khs: $khs,
            total_khs: $khs,
            bus_numbers: $bus,
            temp: $temp,
            fan: $fan
        }'
    )

else
    # If log or config missing, return zero stats
    stats=$(jq -nc \
        --arg ver "$version" \
        --arg algo "$algo" \
        '{hs:[], hs_units:"khs", ver:$ver, algo:$algo, uptime:0, ar:[0,0], khs:0, bus_numbers:[], temp:[], fan:[]}'
    )
fi

# Output final JSON
echo "$stats"
