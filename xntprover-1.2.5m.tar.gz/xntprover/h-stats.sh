#!/usr/bin/env bash
source $MINER_DIR/$CUSTOM_MINER/h-manifest.conf

algo='xnt'
version="1.2.0"
stats=""
unit="M/s"
khs=0

khs=$(tail -n 100 /hive/miners/custom/xntprover/xntprover.log |grep "Total 1m speed(M/s)" | awk 'END {print}'| awk '{print $4}')

# 将M/s转换为kh/s (1 M/s = 1000 kh/s)
khs_num=$(echo "$khs" | jq -R . | jq -s 'map(tonumber)[0] * 1000')

stats=$(jq -nc --argjson khs "$khs_num" \
	--arg hs_units "$unit" \
	--arg ver "$version" \
	--arg algo "$algo" \
	'{"khs":$khs, "hs_units":$hs_units, "ver":$ver, "algo":$algo}')


echo "$stats"
