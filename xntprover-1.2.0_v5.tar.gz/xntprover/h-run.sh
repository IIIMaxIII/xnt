#!/usr/bin/env bash
set -euo pipefail

. /hive/miners/custom/xntprover/h-manifest.conf

cd "$(dirname "$0")"

mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
LOG_FILE="${CUSTOM_LOG_BASENAME}.log"

ARGS="$(cat "$CUSTOM_CONFIG_FILENAME" 2>/dev/null || true)"

exec ./xntprover ${ARGS} 2>&1 | tee -a "$LOG_FILE"
